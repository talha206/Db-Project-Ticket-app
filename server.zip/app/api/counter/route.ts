// app/api/counter/route.ts
import { NextResponse } from "next/server";
import { executeQuery } from "@/lib/db";  // Use the correct function name

export async function GET() {
  try {
    console.log(await executeQuery('SELECT * FROM User_Profile'));  // Correct function name
    const data = await executeQuery("SELECT * FROM User_Profile");  // Correct function name
    return NextResponse.json(data, { status: 200 });
  } catch (error) {
    console.error("API error:", error);
    return NextResponse.json({ error: "Failed to fetch tickets" }, { status: 500 });
  }
}
const url = "localhost:3000/api/counter"