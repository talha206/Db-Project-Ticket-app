 
import { Ticket } from '../lib/types';

export const tickets: Ticket[] = [
  { id: "TECH-122", title: "Set up tailwind config", timeLogged: "1.5d" },
  { id: "TECH-123", title: "Add background and category..", timeLogged: "No time logged.Log time" },
  { id: "TECH-124", title: "Add font sizes and colors", timeLogged: "4d" },
  { id: "TECH-125", title: "Hookup APIs to account pages", timeLogged: "No time logged.Log time" },
  { id: "TECH-126", title: "Set up Datadog to track...", timeLogged: "No time logged.Log time" },
];
