 
export interface Ticket {
    id: string;
    title: string;
    timeLogged: string;
  }
  